// функции
# pragma once

// размер буфера сокета
const int BUFFER_SIZE = 1024;

void handleClient(int clientSocket);